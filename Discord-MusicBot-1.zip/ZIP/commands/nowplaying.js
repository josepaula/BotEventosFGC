const { MessageEmbed } = require("discord.js");
const sendError = require("../util/error")

module.exports = {
  info: {
    name: "nowplaying",
    description: "Mostra a música que está tocando no momento",
    usage: "",
    aliases: ["np"],
  },

  run: async function (client, message, args) {
    const serverQueue = message.client.queue.get(message.guild.id);
    if (!serverQueue) return sendError("There is nothing playing in this server.", message.channel);
    let song = serverQueue.songs[0]
    let thing = new MessageEmbed()
      .setAuthor("Esta tocando agora", "https://raw.githubusercontent.com/SudhanPlayz/Discord-MusicBot/master/assets/Music.gif")
      .setThumbnail(song.img)
      .setColor("BLUE")
      .addField("Música:", song.title, true)
      .addField("Duração", song.duration, true)
      .addField("Adicionado por", song.req.tag, true)
      .setFooter(`${client.user.username}`, client.user.displayAvatarURL)
    return message.channel.send(thing)
  },
};
