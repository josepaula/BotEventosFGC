const { MessageEmbed } = require("discord.js");

module.exports = {
  info: {
    name: "invite",
    description: "Para adicionar / Convidar o bot para seu server.",
    usage: "[invite]",
    aliases: ["inv", "convite"],
  },

  run: async function (client, message, args) {
    
    //set the permissions id here (https://discordapi.com/permissions.html)
    var permissions = 37080128;
    
    let invite = new MessageEmbed()
    .setTitle(`Convide a ${client.user.username}`)
    .setDescription(`Gostou das minhas funções? Clique no link abaixo para me adicionar \n\n [Invite Link](https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=${permissions}&scope=bot)`)
    .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=${permissions}&scope=bot`)
    .setColor("#FFCCCC")
    return message.channel.send(invite);
  },
};
