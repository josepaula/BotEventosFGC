const { MessageEmbed } = require("discord.js");
const sendError = require("../util/error");
const fs = require('fs');


module.exports = {
  info: {
    name: "barra",
    description: "Enviar a barrinha no chat eventos",
    usage: "[b]",
    aliases: ["barra", "barrinha"],
  },

  run: async function (client, message, args) {
  
  let rendom = ["https://media.discordapp.net/attachments/780886013316038656/804326354300436510/22-2.png",
    "https://media.discordapp.net/attachments/780886013316038656/804326355202211840/linha.gif",
    "https://media.discordapp.net/attachments/780886013316038656/804326434574434334/barra43-1.gif",
    "https://media.discordapp.net/attachments/734169056038355086/804460877361053807/20201129_181508.gif",
    "https://media.discordapp.net/attachments/780886013316038656/781595470446723112/barrinhaAnimada-2.gif",
    "https://media.discordapp.net/attachments/780886013316038656/788737170923716619/image0-5-1.gif",
    "https://media.discordapp.net/attachments/780886013316038656/788737395403128832/latest-1.png",
    "https://media.discordapp.net/attachments/780886013316038656/788737453120159794/barrinha-1.gif",
    "https://media.discordapp.net/attachments/780886013316038656/804326435074080798/couple.gif"]
  var rand = rendom[Math.floor(Math.random() * rendom.length)];


  message.channel.send(rand)

}

  
  
  
  }